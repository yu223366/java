#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 Vue 前端构建产物（dist/）复制到后端 Spring Boot 的 static 目录，
使前后端同源（单端口 8080），无需 Nginx、无需跨域配置。

用法：
    python deploy/build-frontend-into-backend.py

前置：先在 wushan-login-vue 目录执行 npm run build 生成 dist/。
"""
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)  # java-main/
DIST = os.path.join(ROOT, "java-main", "wushan-login-vue", "dist")
STATIC = os.path.join(ROOT, "springBootTest", "src", "main", "resources", "static")


def main():
    if not os.path.isdir(DIST):
        print(f"[错误] 未找到前端构建产物：{DIST}")
        print("       请先执行：cd java-main/wushan-login-vue && npm run build")
        return 1
    if not os.path.isdir(STATIC):
        os.makedirs(STATIC, exist_ok=True)

    # 清掉 static 里旧的构建文件（保留 index.html 会被覆盖，其它旧 assets 删除）
    for name in os.listdir(STATIC):
        path = os.path.join(STATIC, name)
        if name == "index.html" or name.startswith("assets"):
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)

    for name in os.listdir(DIST):
        src = os.path.join(DIST, name)
        dst = os.path.join(STATIC, name)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)

    print(f"[完成] 前端产物已注入后端静态目录：{STATIC}")
    print("       重新打包后端即可实现前后端单端口运行。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
