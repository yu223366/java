#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
 雾山五行 · 跨平台一键启动器（无需 Docker）
 适配 Windows / macOS / Linux，自动完成：
   1) 读取 deploy/.env（不存在则用内置默认）
   2) 检测 Java / Node / MySQL 是否就绪
   3) 首次运行自动建库并按顺序导入 db-init/*.sql
   4) 构建 Vue 前端并注入后端 static（前后端同源，单端口）
   5) 打包并启动 Spring Boot（portable 配置，环境变量驱动）
 用法：
   python deploy/start.py            启动
   python deploy/start.py --init-db  仅初始化数据库
   python deploy/start.py --no-build 跳过前端构建（已构建过时加速）
============================================================
"""
import os
import sys
import shutil
import subprocess
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # java-main/
BACKEND = os.path.join(ROOT, "springBootTest")
FRONTEND = os.path.join(ROOT, "java-main", "wushan-login-vue")
DBINIT = os.path.join(HERE, "db-init")
DEFAULT_STATIC = os.path.join(BACKEND, "src", "main", "resources", "static")

DEFAULTS = {
    "WUSHAN_DB_HOST": "localhost",
    "WUSHAN_DB_PORT": "3306",
    "WUSHAN_DB_NAME": "wushan",
    "WUSHAN_DB_USER": "root",
    "WUSHAN_DB_PASSWORD": "123456",
    "SERVER_PORT": "8080",
    "WUSHAN_TOKEN_SECRET": "wushan-wuxing-local-dev-secret",
    "WUSHAN_MYSQL_BIN": "",
}


def log(msg):
    print(f"[雾山] {msg}", flush=True)


def load_env():
    cfg = dict(DEFAULTS)
    env_file = os.path.join(HERE, ".env")
    if not os.path.exists(env_file):
        log("未找到 deploy/.env，使用内置默认配置（建议复制 .env.example 为 .env）")
        return cfg
    with open(env_file, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if k in cfg:
                cfg[k] = v
    return cfg


def run(cmd, cwd=None, check=True, env=None):
    log("执行: " + " ".join(str(c) for c in cmd))
    r = subprocess.run(cmd, cwd=cwd, env=env, check=False)
    if check and r.returncode != 0:
        raise SystemExit(f"[失败] 命令退出码 {r.returncode}: {' '.join(str(c) for c in cmd)}")
    return r


def find_cmd(name, extra=None):
    p = shutil.which(name)
    if p:
        return p
    if extra:
        for c in extra:
            if os.path.exists(c):
                return c
    return None


def check_java():
    j = find_cmd("java")
    if not j:
        raise SystemExit("[失败] 未检测到 Java 17，请先安装 JDK 17 并加入 PATH。")
    out = subprocess.run([j, "-version"], capture_output=True, text=True).stderr
    log("Java 就绪: " + out.splitlines()[0].strip())
    return j


def check_node():
    n = find_cmd("node")
    npm = find_cmd("npm.cmd" if os.name == "nt" else "npm")
    if not n or not npm:
        log("[警告] 未检测到 Node/npm，将跳过前端构建（沿用已有 static）。")
        return None, None
    log("Node 就绪: " + subprocess.run([n, "-v"], capture_output=True, text=True).stdout.strip())
    return n, npm


def find_mysql(cfg):
    explicit = cfg.get("WUSHAN_MYSQL_BIN", "").strip()
    if explicit and os.path.exists(explicit):
        return explicit
    mysql = find_cmd("mysql", [
        r"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe",
        r"C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe",
        "/usr/bin/mysql", "/usr/local/bin/mysql",
    ])
    if not mysql:
        log("[警告] 未检测到 mysql 客户端；若数据库已就绪可忽略，否则请先安装 MySQL 8。")
    return mysql


def init_database(cfg):
    mysql = find_mysql(cfg)
    if not mysql:
        log("[跳过] 无法自动建库（缺 mysql 客户端）。请手动导入 deploy/db-init/ 下的 SQL。")
        return
    host, port = cfg["WUSHAN_DB_HOST"], cfg["WUSHAN_DB_PORT"]
    user, pwd = cfg["WUSHAN_DB_USER"], cfg["WUSHAN_DB_PASSWORD"]
    db = cfg["WUSHAN_DB_NAME"]
    base = [mysql, f"-h{host}", f"-P{port}", f"-u{user}", f"-p{pwd}",
            "--default-character-set=utf8mb4", "-e"]
    try:
        run(base + [f"CREATE DATABASE IF NOT EXISTS `{db}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"], check=False)
        log("数据库已就绪: " + db)
    except Exception as e:
        log("[警告] 建库失败，可能数据库已存在或连接异常: " + str(e))

    scripts = sorted(f for f in os.listdir(DBINIT) if f.lower().endswith(".sql"))
    for s in scripts:
        log(f"导入 {s} ...")
        cmd = [mysql, f"-h{host}", f"-P{port}", f"-u{user}", f"-p{pwd}",
               "--default-character-set=utf8mb4", db]
        with open(os.path.join(DBINIT, s), "rb") as fh:
            r = subprocess.run(cmd, stdin=fh, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if r.returncode != 0:
            log(f"  [警告] {s} 导入有报错（若为重复字段/表可忽略）: "
                + r.stderr.decode("utf-8", "ignore")[:200])
    log("数据库初始化流程结束。")


def build_frontend(npm):
    if not npm:
        return False
    env = os.environ.copy()
    env["VITE_USE_MOCK"] = "false"
    env["VITE_API_BASE_URL"] = "/api"
    run(["npm", "run", "build"], cwd=FRONTEND, env=env)
    return True


def inject_static():
    dist = os.path.join(FRONTEND, "dist")
    if not os.path.isdir(dist):
        log("[跳过] 未找到前端 dist，沿用后端已有 static。")
        return
    os.makedirs(DEFAULT_STATIC, exist_ok=True)
    for name in os.listdir(DEFAULT_STATIC):
        p = os.path.join(DEFAULT_STATIC, name)
        if name == "index.html" or name.startswith("assets"):
            if os.path.isdir(p):
                shutil.rmtree(p)
            else:
                os.remove(p)
    for name in os.listdir(dist):
        src, dst = os.path.join(dist, name), os.path.join(DEFAULT_STATIC, name)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)
    log("前端产物已注入后端 static（同源单端口）。")


def build_backend_maven():
    mvnw = os.path.join(BACKEND, "mvnw.cmd" if os.name == "nt" else "mvnw")
    if os.name != "nt":
        os.chmod(mvnw, 0o755)
    run([mvnw, "-q", "-B", "clean", "package", "-DskipTests"], cwd=BACKEND)
    jars = [f for f in os.listdir(os.path.join(BACKEND, "target")) if f.endswith(".jar") and "sources" not in f]
    if not jars:
        raise SystemExit("[失败] 未找到打包后的 jar。")
    return os.path.join(BACKEND, "target", jars[0])


def start_backend(jar, cfg):
    env = os.environ.copy()
    env.update({
        "SPRING_PROFILES_ACTIVE": "portable",
        "WUSHAN_DB_HOST": cfg["WUSHAN_DB_HOST"],
        "WUSHAN_DB_PORT": cfg["WUSHAN_DB_PORT"],
        "WUSHAN_DB_NAME": cfg["WUSHAN_DB_NAME"],
        "WUSHAN_DB_USER": cfg["WUSHAN_DB_USER"],
        "WUSHAN_DB_PASSWORD": cfg["WUSHAN_DB_PASSWORD"],
        "WUSHAN_TOKEN_SECRET": cfg["WUSHAN_TOKEN_SECRET"],
        "SERVER_PORT": cfg["SERVER_PORT"],
    })
    port = cfg["SERVER_PORT"]
    log(f"启动后端：http://localhost:{port}")
    log("按 Ctrl+C 停止服务。")
    run([find_cmd("java"), "-jar", jar], cwd=BACKEND, env=env, check=False)


def main():
    args = set(sys.argv[1:])
    cfg = load_env()
    check_java()

    if "--init-db" in args:
        init_database(cfg)
        log("仅初始化数据库完成。")
        return

    init_database(cfg)

    node, npm = check_node()
    if "--no-build" not in args:
        if build_frontend(npm):
            inject_static()
    else:
        log("跳过前端构建。")

    jar = build_backend_maven()
    start_backend(jar, cfg)


if __name__ == "__main__":
    main()
